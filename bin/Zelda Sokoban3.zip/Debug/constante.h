#ifndef CONSTANTE_H_INCLUDED
#define CONSTANTE_H_INCLUDED

enum{haut,bas,gauche,droite};

#endif // CONSTANTE_H_INCLUDED
