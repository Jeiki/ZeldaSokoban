#ifndef ANIMATION_H_INCLUDED
#define ANIMATION_H_INCLUDED


void transition(SDL_Surface *ecran, int typeTransition);
void deplacement(SDL_Surface *ecran,int direction,SDL_Rect posLink);

#endif // ANIMATION_H_INCLUDED
